sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("project10.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map