sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/m/MessageToast"
], function (
    Controller,
    JSONModel,
    MessageBox,
    MessageToast
) {
    "use strict";

    return Controller.extend("project10.controller.View2", {

        onInit: function () {

            var oModel = new JSONModel({
                dateTime: ""
            });

            this.getView().setModel(oModel, "dashboard");

            this._updateClock();
        },

        _updateClock: function () {

            var oModel =
                this.getView().getModel("dashboard");

            setInterval(function () {

                oModel.setProperty(
                    "/dateTime",
                    new Date().toLocaleString("en-IN")
                );

            }, 1000);
        },

        onLogout: function () {

            MessageBox.confirm(
                "Are you sure you want to logout?",
                {
                    onClose: function (sAction) {

                        if (sAction === "OK") {

                            window.location.href =
                                "/index.html";
                        }
                    }
                }
            );
        },

        onStartCamera: function () {

            MessageToast.show(
                "Camera Started"
            );
        },

        onCapturePhoto: function () {

            MessageToast.show(
                "Photo Captured"
            );
        },
        onStartCamera: async function () {

    try {

        const stream =
            await navigator.mediaDevices.getUserMedia({
                video: true
            });

        const video =
            document.getElementById("cameraVideo");

        if (video) {
            video.srcObject = stream;
        }

        this._cameraStream = stream;

    } catch (error) {

        sap.m.MessageBox.error(
            "Camera access denied or unavailable."
        );

        console.error(error);
    }
},

onCapturePhoto: function () {

    if (!this._cameraStream) {

        sap.m.MessageToast.show(
            "Start camera first"
        );

        return;
    }

    sap.m.MessageToast.show(
        "Photo captured"
    );
}

    });

});

