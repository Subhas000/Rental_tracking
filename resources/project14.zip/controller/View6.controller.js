sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("project14.controller.View6",{onInit(){}})});
//# sourceMappingURL=View6.controller.js.map