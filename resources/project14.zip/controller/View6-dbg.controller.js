sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("project14.controller.View6", {
        onInit() {
        }
    });
});