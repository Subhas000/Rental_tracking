sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("project12.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map